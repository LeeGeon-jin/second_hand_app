require('dotenv').config();
const axios = require('axios');

async function testHuggingFace() {
  try {
    console.log('🔍 测试Hugging Face API连接...');
    console.log('API Token:', process.env.HUGGING_FACE_TOKEN ? '已配置' : '未配置');

    if (!process.env.HUGGING_FACE_TOKEN || process.env.HUGGING_FACE_TOKEN === 'your_hf_token_here') {
      console.log('❌ 请先配置Hugging Face API Token');
      console.log('📝 获取Token步骤：');
      console.log('1. 访问 https://huggingface.co/');
      console.log('2. 注册免费账户');
      console.log('3. 进入 Settings > Access Tokens');
      console.log('4. 创建新的Token');
      console.log('5. 将Token添加到.env文件中');
      return;
    }

    const response = await axios.post('https://api-inference.huggingface.co/models/distilgpt2', {
      inputs: 'Hello, please respond with "API connection successful"'
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.HUGGING_FACE_TOKEN}`,
        'Content-Type': 'application/json'
      },
      timeout: 10000
    });

    console.log('✅ Hugging Face API连接成功！');
    console.log('回复:', response.data[0]?.generated_text || '无回复');

  } catch (error) {
    console.log('❌ Hugging Face API连接失败:');
    if (error.response) {
      console.log('状态码:', error.response.status);
      console.log('错误信息:', error.response.data?.error || '未知错误');
    } else {
      console.log('网络错误:', error.message);
    }
  }
}

testHuggingFace();
