require('dotenv').config();
const axios = require('axios');

async function testOpenAI() {
  try {
    console.log('🔍 测试OpenAI API连接...');
    console.log('API Key:', process.env.OPENAI_API_KEY ? '已配置' : '未配置');
    
    if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'your_openai_api_key_here') {
      console.log('❌ 请先配置OpenAI API Key');
      return;
    }

    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-4o',
      messages: [
        {
          role: 'user',
          content: '你好，请回复"API连接成功"'
        }
      ],
      max_tokens: 50
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ OpenAI API连接成功！');
    console.log('回复:', response.data.choices[0].message.content);
    
  } catch (error) {
    console.log('❌ OpenAI API连接失败:');
    if (error.response) {
      console.log('状态码:', error.response.status);
      console.log('错误信息:', error.response.data.error?.message || '未知错误');
    } else {
      console.log('网络错误:', error.message);
    }
  }
}

testOpenAI();
