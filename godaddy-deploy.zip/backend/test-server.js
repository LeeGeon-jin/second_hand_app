// 测试服务器启动
try {
  console.log('正在启动服务器...');
  require('./server.js');
  console.log('服务器启动成功');
} catch (error) {
  console.error('服务器启动失败:', error.message);
  console.error('错误堆栈:', error.stack);
}
