require('dotenv').config();
const axios = require('axios');

async function testSimpleHF() {
  try {
    console.log('🔍 简单测试Hugging Face API...');
    console.log('Token:', process.env.HUGGING_FACE_TOKEN ? '已配置' : '未配置');

    const token = process.env.HUGGING_FACE_TOKEN;
    if (!token) {
      console.log('❌ 没有找到Token');
      return;
    }

    // 测试一个更基础的模型
    const response = await axios.post('https://api-inference.huggingface.co/models/sshleifer/tiny-gpt2', {
      inputs: 'Hello world'
    }, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      timeout: 10000
    });

    console.log('✅ API连接成功！');
    console.log('响应状态:', response.status);
    console.log('响应数据:', JSON.stringify(response.data, null, 2));

  } catch (error) {
    console.log('❌ API连接失败:');
    if (error.response) {
      console.log('状态码:', error.response.status);
      console.log('状态文本:', error.response.statusText);
      console.log('响应头:', error.response.headers);
      console.log('响应数据:', JSON.stringify(error.response.data, null, 2));
    } else {
      console.log('网络错误:', error.message);
    }
  }
}

testSimpleHF();
